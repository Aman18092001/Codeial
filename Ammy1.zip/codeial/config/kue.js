const kue=require('kue');
const Queue=kue.createQueue();

module.exports=Queue;